export interface JobCreation {

    JobGroupID:Number;
    JobCategoryID:string;
    DueDate:Number;
    JobTitle:string;
    Charge:string;
    Description:string;
}
